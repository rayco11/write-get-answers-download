# Write Get Answers — Chrome Extension

A Chrome Manifest V3 extension with a right-side in-page drawer on ordinary webpages, a Chrome side panel, selected-text actions, a context menu, a popup, settings, local calculations, multi-result public-source research, free translation fallback, clickable source links, and an Answer-only view.

## Install on Windows 11

1. Extract the downloaded ZIP to a normal folder.
2. Open Chrome and visit `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `write_get_answers_extension` folder (the folder containing `manifest.json`).
6. Pin **Write Get Answers** to the toolbar.
7. Open a regular webpage, select text, and use the floating Ask/Explain/Translate/Research toolbar or right-click and choose **Research / answer with Write Get Answers**.

The floating toolbar opens an in-page right drawer. The extension icon opens Chrome’s side panel. You can also use **Alt+Shift+G**; change this in `chrome://extensions/shortcuts`.

## What works without an API key?

- Select text on most ordinary HTTP/HTTPS pages; a small Ask / Explain / Translate toolbar appears.
- Clicking an action opens a right-side drawer directly on that webpage and immediately displays a result.
- The drawer also supports a typed question, target-language selection, copy, and close controls.
- Basic arithmetic such as `9 × 9`, `12 + 30`, and `(5 + 2) * 3` is calculated locally.
- Research queries search Wikipedia and try DuckDuckGo Instant Answer, then display multiple source links when results are available.
- The Research action does not need an API key and shows source links that can be opened for verification.
- The Answer only toggle hides surrounding controls so the answer has more room.
- A basic summary fallback works locally.

**Important limitation:** no-key public services are not a full AI model. They may fail, rate-limit, return no result, or provide limited answers. This version cannot reliably answer every arbitrary question, perform a full AI explanation, or translate every long passage. Without a key, this is a research-and-utility assistant, not a full generative AI model. It cannot reliably synthesize an expert answer for every possible topic. Full open-ended AI explanations require a local model or a hosted AI service; the extension does not pretend otherwise.

## Optional: configure an AI provider

The extension no longer requires an API key for the basic no-key features. If you want more complete AI answers, open the extension's **Settings** page and select **OpenAI-compatible chat API**. Fill in:
- Endpoint URL: a provider endpoint compatible with `/chat/completions`, or a full `/chat/completions` URL.
- Model: the model identifier accepted by that provider.
- API key: your provider key.

This implementation sends requests from the extension to the configured endpoint. Provider CORS and endpoint compatibility vary. The API key is stored in local extension storage, which is not a secure secrets vault; do not share/publish an extension containing a personal key. For a distributable extension, use a private backend proxy instead. Selected text can be sent to the provider when external requests are allowed.

## Notes and limitations

- Chrome prevents content scripts from running on browser-internal pages, the Chrome Web Store, and some protected frames or document viewers.
- The floating toolbar is injected on ordinary HTTP/HTTPS pages only.
- Some sites may stop or restyle injected UI; reload the page after installing/updating the extension.
- Public-source research is implemented with free endpoints, but it is not a comprehensive search of the entire internet. Search endpoints can be unavailable or rate-limited, and sources can be incomplete. The extension never guarantees every answer is correct; verify important claims using the linked original sources.
- Test provider configuration with a non-sensitive sample before using it for private text.


## Selection drawer behavior

The content script injects a right-side drawer into ordinary web pages so the selected text and answer can be shown even if Chrome does not open its native side panel from a content-script click. This is not available on Chrome internal pages, Chrome Web Store pages, and other restricted pages. Reload pages after installing or updating the extension.


## Version 2.2.0 upgrade
- Added topic selection (Auto-detect, Music, School, Coding, Science, History, Gaming, Writing, Web research, General).
- Added answer-language selection and more language codes for free public translation. The public translation service may have length limits and does not guarantee perfect results.
- Added conservative correction for a small set of common English and Dutch typos; unknown words and names are preserved. This is not a full typo-proof AI model.
- Added premium gold name tag and gold-accented controls.
- Default usage remains no API key. Public research/translation requires an internet connection and sends the requested query/text to those public services.


## Version 2.2.0 research upgrade

- Adds best-effort public-source lookups across Wikipedia, Wikidata, DuckDuckGo Instant Answer, and OpenAlex academic records for suitable topics.
- Adds direct Google, Bing, and Brave search links, plus Khan Academy and Google Scholar links for school/research topics. Search links are suggestions to open, not sources the extension claims to have read.
- School mode is designed as a learning helper: it encourages worked steps, source checking, and understanding rather than presenting unsupported claims as facts.
- All research integrations work without a user-supplied API key, but public services can rate-limit, change, or fail. This is not a full AI model or a complete search of the entire internet.


## Version 2.3.0 — cinematic welcome
- Clicking the extension toolbar icon opens a 10-second animated welcome scene, with the two requested messages and a fade into the main assistant page.
- The intro uses a black-and-gold cinematic style, animated typography, a glowing logo, moving light orbs, subtle reflections/highlights, a perspective grid and progress bar.
- Browser security does not let an extension silently force true operating-system/browser fullscreen. The welcome experience fills its tab; users can press F11 if they want the browser in fullscreen.


## Version 2.5.0 — launch fix + teacher mode

- Fixed the cutscene launch path: Chrome action icon has no `default_popup`, allowing `chrome.action.onClicked` to open the full-tab welcome experience. The existing 10-second welcome animation then transitions to the assistant. Use F11 for browser fullscreen; extensions cannot silently force the browser/OS into fullscreen.
- Added an explanation style selector: `Explain like I'm 7`, `Normal explanation`, and `Exam prep · detailed steps`. The configured AI-provider prompt receives this style and the saved personalization preferences.
- Added a 100-item preference library grouped into ten searchable categories; options are persisted in Chrome storage and sent as instructions to configured AI providers. In public-source-only mode, they do not magically create an offline LLM.
- Changed default visual direction to ivory/white + gold, with a dark-gold theme and a reduced-motion accessibility fallback.
- Fixed arithmetic parsing so `10:2` is interpreted as school-maths division and returns 5, with a teacher-style explanation. It does not interpret that expression as clock time.
- Research mode includes optional links to legitimate learning resources and distinguishes source records from search links. The product takes inspiration from stepwise math explanations, practice-based study modes, and transparent source handling; it does not recommend bypassing school rules.

## Build/QA prompt used for this upgrade

> Act as a careful Chrome Extension Manifest V3 engineer and educational UX designer. Inspect the real current package before editing. Find the actual launch path and reproduce the reported bug from code. Fix the launch mechanism first; do not add decorative UI as a substitute for wiring. The welcome cutscene must start from the browser toolbar icon, display two messages over about ten seconds in a full browser tab, respect reduced-motion preferences, and then route to the working assistant. Verify that the extension action does not define a competing popup if it relies on `chrome.action.onClicked`. Make `:` act as division in a school-maths expression (e.g. 10:2 = 5), show the calculation steps, and ensure this is handled locally. Add teacher modes and saved preferences, preserving a clear distinction between the no-key public-source mode and any configured generative AI provider. Research reputable learning tools and browser extension/animation guidance; cite research in the release notes. Never claim all features work without testing them. Run JavaScript syntax checks, validate the manifest, test the ZIP, run targeted math tests, and be explicit that only live browser testing can confirm visual behavior end-to-end.


## 2.5.0 updates
- The toolbar click opens the real Chrome side panel from the original click. The 10-second intro then closes and returns to the website instead of navigating to a standalone sidepanel.html tab. Escape and Skip Intro are supported.
- The in-page selection helper now has a persistent left/right dock control and a consistent gold/ivory design.
- The side-panel chat shows a transcript instead of replacing the previous message on each question. Recent transcript can be saved locally if enabled.
- Free lookup answers use a short-lived in-memory cache, and Wikipedia summary requests run concurrently for faster repeated/simple lookups.
- Chrome's built-in side-panel position is controlled by Chrome itself; the extension can show the current side and open Chrome Appearance settings, but it cannot force the native panel to switch sides through the public API. The in-page website helper can switch sides directly.
