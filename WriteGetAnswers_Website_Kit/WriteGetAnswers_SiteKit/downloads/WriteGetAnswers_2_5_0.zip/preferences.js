(function(){
  const groups = [
    { category: "Teacher & clarity", items: [
      {"key": "pref_answerDirectly", "label": "Give the answer first", "instruction": "Give the direct answer first, then explain it.", "defaultValue": true},
      {"key": "pref_defineKeywords", "label": "Define key words", "instruction": "Define important vocabulary before using it.", "defaultValue": true},
      {"key": "pref_stepByStep", "label": "Show steps", "instruction": "Show the reasoning as clear numbered steps and do not skip important transitions.", "defaultValue": true},
      {"key": "pref_shortSentences", "label": "Use short sentences", "instruction": "Prefer short, clear sentences.", "defaultValue": true},
      {"key": "pref_analogy", "label": "Use a simple analogy", "instruction": "Use one accurate, familiar analogy when it helps.", "defaultValue": false},
      {"key": "pref_workedExample", "label": "Include a worked example", "instruction": "Include one worked example when useful.", "defaultValue": false},
      {"key": "pref_avoidJargon", "label": "Avoid jargon", "instruction": "Avoid unexplained jargon; define technical words.", "defaultValue": false},
      {"key": "pref_recap", "label": "Add a recap", "instruction": "End with a brief recap of the most important idea.", "defaultValue": false},
      {"key": "pref_explainWhy", "label": "Explain why", "instruction": "Explain why the answer is correct, not only what it is.", "defaultValue": true},
      {"key": "pref_checkUnderstanding", "label": "Check understanding", "instruction": "End with one short check-for-understanding question when appropriate.", "defaultValue": false}
    ]},
    { category: "Maths & calculations", items: [
      {"key": "pref_mathShowIntermediate", "label": "Show intermediate steps", "instruction": "For maths, show each important intermediate step.", "defaultValue": false},
      {"key": "pref_mathCheck", "label": "Check the result", "instruction": "Verify arithmetic by using an inverse operation or substitution when possible.", "defaultValue": true},
      {"key": "pref_mathEstimate", "label": "Estimate first", "instruction": "Give a quick estimate before exact arithmetic when useful.", "defaultValue": false},
      {"key": "pref_mathFormula", "label": "Name the formula", "instruction": "State the formula used and define its variables.", "defaultValue": false},
      {"key": "pref_mathUnits", "label": "Track units", "instruction": "Keep units attached to values and include correct units in the result.", "defaultValue": false},
      {"key": "pref_mathExplainSymbols", "label": "Explain symbols", "instruction": "Explain symbols such as ÷, :, %, and exponents in context.", "defaultValue": false},
      {"key": "pref_mathAlternative", "label": "Show another method", "instruction": "Offer a second method when it helps the student compare approaches.", "defaultValue": false},
      {"key": "pref_mathCommonErrors", "label": "Mention common errors", "instruction": "Warn about one likely mistake for this kind of calculation.", "defaultValue": false},
      {"key": "pref_mathNumbered", "label": "Number calculation lines", "instruction": "Put multi-line calculations in numbered steps.", "defaultValue": false},
      {"key": "pref_mathRoundNote", "label": "Explain rounding", "instruction": "State if and why rounding is used.", "defaultValue": false}
    ]},
    { category: "Writing & language", items: [
      {"key": "pref_writingCorrectedFirst", "label": "Show corrected version first", "instruction": "For proofreading, show the corrected version first.", "defaultValue": false},
      {"key": "pref_writingExplainEdits", "label": "Explain edits", "instruction": "Briefly explain meaningful grammar or wording edits.", "defaultValue": false},
      {"key": "pref_writingPreserveVoice", "label": "Preserve my voice", "instruction": "Preserve the writer’s intended meaning and personal voice.", "defaultValue": false},
      {"key": "pref_writingAlternatives", "label": "Offer alternatives", "instruction": "Offer two alternative phrasings if that would help.", "defaultValue": false},
      {"key": "pref_writingTone", "label": "Label the tone", "instruction": "Name the tone of a suggested rewrite when relevant.", "defaultValue": false},
      {"key": "pref_writingGrammar", "label": "Explain grammar", "instruction": "Explain the key grammar rule behind a correction.", "defaultValue": false},
      {"key": "pref_writingSpelling", "label": "Flag spelling patterns", "instruction": "Point out recurring spelling patterns without shaming the learner.", "defaultValue": false},
      {"key": "pref_writingVocabulary", "label": "Suggest vocabulary", "instruction": "Offer useful vocabulary alternatives with meaning differences.", "defaultValue": false},
      {"key": "pref_writingBilingual", "label": "Support bilingual learners", "instruction": "Explain tricky language points in plain language for a bilingual learner.", "defaultValue": false},
      {"key": "pref_writingMinimal", "label": "Avoid unnecessary rewriting", "instruction": "Do not rewrite text that is already clear; change only what needs improving.", "defaultValue": false}
    ]},
    { category: "Research & sources", items: [
      {"key": "pref_researchCitations", "label": "Cite sources", "instruction": "Include direct source URLs for factual claims whenever reliable sources are available.", "defaultValue": true},
      {"key": "pref_researchSeparateClaims", "label": "Separate evidence from explanation", "instruction": "Separate claims supported by sources from your own explanation.", "defaultValue": false},
      {"key": "pref_researchOfficial", "label": "Prefer official sources", "instruction": "Prefer official, primary, or institutional sources when suitable.", "defaultValue": true},
      {"key": "pref_researchAcademic", "label": "Use scholarly evidence", "instruction": "Use academic sources for scholarly questions when suitable.", "defaultValue": false},
      {"key": "pref_researchCompare", "label": "Compare sources", "instruction": "Compare more than one source and point out meaningful differences.", "defaultValue": false},
      {"key": "pref_researchDates", "label": "Include dates", "instruction": "Include publication dates or the date of an event when relevant.", "defaultValue": false},
      {"key": "pref_researchUncertainty", "label": "State uncertainty", "instruction": "Clearly state uncertainty and missing evidence.", "defaultValue": false},
      {"key": "pref_researchSearchLinks", "label": "Label search links honestly", "instruction": "Clearly distinguish links actually consulted from search links that the user can open.", "defaultValue": false},
      {"key": "pref_researchNoInvented", "label": "Never invent citations", "instruction": "Never invent quotes, authors, page titles, citations, or URLs.", "defaultValue": true},
      {"key": "pref_researchEvidence", "label": "Summarize evidence", "instruction": "Briefly explain what each cited source contributes.", "defaultValue": false}
    ]},
    { category: "Study & memory", items: [
      {"key": "pref_studyPractice", "label": "Add practice question", "instruction": "Add one practice question after an explanation when appropriate.", "defaultValue": true},
      {"key": "pref_studyQuiz", "label": "Quiz me", "instruction": "Offer a short self-test instead of only giving a final answer.", "defaultValue": false},
      {"key": "pref_studyFlashcards", "label": "Create flashcards", "instruction": "When asked to study, convert key terms into question-and-answer flashcards.", "defaultValue": false},
      {"key": "pref_studyMemoryTip", "label": "Give memory tips", "instruction": "Add a useful memory tip or mnemonic when appropriate.", "defaultValue": false},
      {"key": "pref_studyMistakes", "label": "Explain common mistakes", "instruction": "Explain common misconceptions for the topic.", "defaultValue": false},
      {"key": "pref_studyGradual", "label": "Build difficulty gradually", "instruction": "Start with a simple example, then increase difficulty.", "defaultValue": false},
      {"key": "pref_studyHintFirst", "label": "Give a hint first", "instruction": "When the student asks for a hint, give a hint without revealing the full answer.", "defaultValue": false},
      {"key": "pref_studyExamReview", "label": "Make an exam recap", "instruction": "For revision requests, end with a compact exam-review checklist.", "defaultValue": false},
      {"key": "pref_studyDefinitions", "label": "Include definitions", "instruction": "Define the key terms the learner needs for this task.", "defaultValue": false},
      {"key": "pref_studyGoal", "label": "State the learning goal", "instruction": "State the main thing the student should understand after the explanation.", "defaultValue": false}
    ]},
    { category: "Answer format & tone", items: [
      {"key": "pref_formatConcise", "label": "Be concise by default", "instruction": "Keep the answer focused and remove repetition.", "defaultValue": true},
      {"key": "pref_formatDetailed", "label": "Explain details when asked", "instruction": "When asked for detail, expand the reasoning instead of padding the answer.", "defaultValue": false},
      {"key": "pref_formatHeadings", "label": "Use headings", "instruction": "Use short headings for multi-part answers.", "defaultValue": false},
      {"key": "pref_formatBullets", "label": "Use bullet points", "instruction": "Use bullets for parallel ideas.", "defaultValue": false},
      {"key": "pref_formatNumbered", "label": "Use numbered lists", "instruction": "Use numbered steps for ordered procedures.", "defaultValue": false},
      {"key": "pref_formatPlainLanguage", "label": "Use plain language", "instruction": "Prefer plain language over formal jargon.", "defaultValue": false},
      {"key": "pref_formatAgeAppropriate", "label": "Keep it learner-friendly", "instruction": "Keep examples and explanations appropriate for a school learner.", "defaultValue": false},
      {"key": "pref_formatProfessional", "label": "Keep tone respectful", "instruction": "Use a respectful and clear tone.", "defaultValue": false},
      {"key": "pref_formatFriendly", "label": "Be encouraging", "instruction": "Be encouraging without exaggerated praise or infantilizing language.", "defaultValue": false},
      {"key": "pref_formatNoEmoji", "label": "Avoid emojis", "instruction": "Avoid emojis unless the user asks for them.", "defaultValue": false}
    ]},
    { category: "Science, history & systems", items: [
      {"key": "pref_scienceUnits", "label": "Use scientific units", "instruction": "Use standard scientific units and explain conversions.", "defaultValue": false},
      {"key": "pref_scienceMethod", "label": "Explain scientific method", "instruction": "For science questions, distinguish observation, hypothesis, experiment, and conclusion when relevant.", "defaultValue": false},
      {"key": "pref_scienceCausality", "label": "Explain causes carefully", "instruction": "Distinguish cause from coincidence and describe mechanisms when known.", "defaultValue": false},
      {"key": "pref_scienceCorrelation", "label": "Distinguish correlation", "instruction": "Do not describe correlation as causation without evidence.", "defaultValue": false},
      {"key": "pref_historyTimeline", "label": "Add a timeline", "instruction": "For history questions, order the key events chronologically.", "defaultValue": false},
      {"key": "pref_historyPrimary", "label": "Distinguish source types", "instruction": "Distinguish primary sources from later interpretations when relevant.", "defaultValue": false},
      {"key": "pref_historyPerspectives", "label": "Include perspectives", "instruction": "Explain relevant perspectives without treating unsupported claims as equal evidence.", "defaultValue": false},
      {"key": "pref_historyContext", "label": "Explain historical context", "instruction": "Explain what was happening at the time before judging historical events.", "defaultValue": false},
      {"key": "pref_systemsConnections", "label": "Connect related systems", "instruction": "Explain how related parts interact when that helps understanding.", "defaultValue": false},
      {"key": "pref_scienceLimits", "label": "Mention scientific limits", "instruction": "Mention important limitations, uncertainty, or consensus when relevant.", "defaultValue": false}
    ]},
    { category: "Language support", items: [
      {"key": "pref_languageTarget", "label": "Respect selected language", "instruction": "Answer in the selected answer language, preserving key subject terminology.", "defaultValue": false},
      {"key": "pref_languageTranslateTerms", "label": "Translate key terms", "instruction": "Give translations of important terms when useful.", "defaultValue": false},
      {"key": "pref_languageFormatting", "label": "Preserve formatting", "instruction": "Preserve meaningful headings, lists, equations, and code formatting.", "defaultValue": false},
      {"key": "pref_languageGlossary", "label": "Add a bilingual glossary", "instruction": "Provide a small bilingual glossary for difficult terms when useful.", "defaultValue": false},
      {"key": "pref_languagePronunciation", "label": "Give pronunciation help", "instruction": "Add pronunciation guidance for requested language-learning tasks.", "defaultValue": false},
      {"key": "pref_languageSimpleWords", "label": "Use accessible vocabulary", "instruction": "Use common words before advanced synonyms.", "defaultValue": false},
      {"key": "pref_languageNatural", "label": "Sound natural", "instruction": "Prefer natural phrasing over word-for-word translation.", "defaultValue": false},
      {"key": "pref_languageLiteralWarning", "label": "Note idioms", "instruction": "Explain idioms that do not translate literally.", "defaultValue": false},
      {"key": "pref_languageGrammarNotes", "label": "Add grammar notes", "instruction": "Briefly explain grammar patterns in language-learning answers.", "defaultValue": false},
      {"key": "pref_languageNames", "label": "Preserve proper names", "instruction": "Preserve proper names and clearly mark uncertain transliterations.", "defaultValue": false}
    ]},
    { category: "Critical thinking & responsible learning", items: [
      {"key": "pref_criticalProsCons", "label": "Show pros and cons", "instruction": "For decision or evaluation questions, present the strongest relevant pros and cons.", "defaultValue": false},
      {"key": "pref_criticalInterpretations", "label": "Consider alternatives", "instruction": "Mention other plausible interpretations when relevant.", "defaultValue": false},
      {"key": "pref_criticalFactOpinion", "label": "Separate fact and opinion", "instruction": "Clearly distinguish factual statements from opinions or recommendations.", "defaultValue": false},
      {"key": "pref_criticalConfidence", "label": "Calibrate confidence", "instruction": "Use confidence language that matches the evidence.", "defaultValue": false},
      {"key": "pref_criticalBias", "label": "Check for bias", "instruction": "Notice potential bias in sources and explain it carefully.", "defaultValue": false},
      {"key": "pref_criticalUnknowns", "label": "Name missing information", "instruction": "State what additional information could change the answer.", "defaultValue": false},
      {"key": "pref_criticalErrorCheck", "label": "Check possible errors", "instruction": "Double-check calculations, names, and key facts before answering.", "defaultValue": false},
      {"key": "pref_criticalLimitations", "label": "Explain limitations", "instruction": "State important limitations of the answer or method.", "defaultValue": false},
      {"key": "pref_criticalFollowups", "label": "Suggest a next step", "instruction": "Offer one useful follow-up activity or next step.", "defaultValue": false},
      {"key": "pref_criticalSourceQuality", "label": "Evaluate source quality", "instruction": "Briefly assess source relevance, authority, and freshness when possible.", "defaultValue": false}
    ]},
    { category: "Academic integrity & privacy", items: [
      {"key": "pref_integrityLearn", "label": "Teach rather than only copy", "instruction": "Prioritize understanding and worked reasoning, not only a ready-to-submit answer.", "defaultValue": true},
      {"key": "pref_integrityCite", "label": "Help cite sources", "instruction": "Remind the student to cite sources when their assignment requires it.", "defaultValue": false},
      {"key": "pref_integrityOwnWords", "label": "Encourage own words", "instruction": "Encourage the student to restate ideas in their own words.", "defaultValue": false},
      {"key": "pref_integrityDisclose", "label": "Respect assignment rules", "instruction": "Remind the student to follow teacher or school rules about AI assistance.", "defaultValue": false},
      {"key": "pref_integrityNoPlagiarism", "label": "Avoid plagiarism", "instruction": "Do not present someone else’s writing as the student’s original work.", "defaultValue": false},
      {"key": "pref_privacyMinimize", "label": "Minimize personal data", "instruction": "Do not request or repeat personal information that is unnecessary for the task.", "defaultValue": false},
      {"key": "pref_privacyNoSources", "label": "No fabricated evidence", "instruction": "Be explicit when a claim could not be verified instead of making up supporting evidence.", "defaultValue": false},
      {"key": "pref_integrityUncertainty", "label": "Do not bluff", "instruction": "Say when you do not know, cannot access a source, or cannot verify a claim.", "defaultValue": false},
      {"key": "pref_integritySafety", "label": "Keep advice appropriate", "instruction": "Keep school examples and advice safe, age-appropriate, and respectful.", "defaultValue": false},
      {"key": "pref_integrityCiteOwn", "label": "Separate own explanation from source text", "instruction": "Paraphrase sources in original wording and mark direct quotations clearly.", "defaultValue": false}
    ]}
  ];
  window.WGA_PREFS = groups;
})();
