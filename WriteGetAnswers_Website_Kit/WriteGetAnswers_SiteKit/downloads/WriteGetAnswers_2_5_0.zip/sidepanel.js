const $ = id => document.getElementById(id);
let selected = "";
let action = "ask";
let busy = false;
let lastAnswer = "";
let lastUserPrompt = "";
let history = [];

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[c]));
}
function renderMarkdown(md) {
  // Small, dependency-free renderer for trusted text returned by the user's configured provider.
  let s = escapeHtml(md);
  s = s.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
  s = s.replace(/^### (.*)$/gm, "<h3>$1</h3>").replace(/^## (.*)$/gm, "<h2>$1</h2>").replace(/^# (.*)$/gm, "<h2>$1</h2>");
  s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>").replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/(https?:\/\/[^\s<]+)/g, url => { const clean = url.replace(/[),.]+$/g, ""); return `<a href="${clean}" target="_blank" rel="noopener noreferrer">${clean}</a>${url.slice(clean.length)}`; });
  s = s.replace(/^&gt; (.*)$/gm, "<blockquote>$1</blockquote>");
  s = s.replace(/(?:^|\n)- (.*)/g, "\n<li>$1</li>");
  s = s.replace(/(?:^|\n)\d+\. (.*)/g, "\n<li>$1</li>");
  s = s.replace(/(<li>.*<\/li>\n?)+/gs, m => `<ul>${m}</ul>`);
  return s.split(/\n{2,}/).map(part => /^(<h[23]|<pre|<ul|<blockquote)/.test(part.trim()) ? part : `<p>${part.replace(/\n/g, "<br>")}</p>`).join("");
}
function renderConversation(messages = history, pending = false) {
  if (!messages.length && !pending) return '<div class="welcome-icon">✦</div><h2>Your ideas, understood.</h2><p>Select text on any regular webpage, or type a question below. Pick a topic or use Auto-detect. Ask in your own language—even with typos—and get a clearer answer.</p><div class="suggestions"><button data-suggestion="Explain this in simple words">Explain simply</button><button data-suggestion="Give me the answer and show the steps">Show the steps</button><button data-suggestion="Translate this into Dutch">Translate to Dutch</button></div>';
  const items = messages.map((item, index) => {
    const role = item.role === 'user' ? 'you' : 'tutor';
    const content = item.role === 'user' ? `<p>${escapeHtml(item.content).replace(/\n/g,'<br>')}</p>` : renderMarkdown(item.content || '');
    return `<article class="chat-message ${item.role === 'user' ? 'from-user' : 'from-tutor'}"><div class="message-author">${role === 'you' ? 'YOU' : 'WRITE GET ANSWERS'}</div><div class="message-body">${content}</div></article>`;
  }).join('');
  return items + (pending ? '<article class="chat-message from-tutor pending-message"><div class="message-author">WRITE GET ANSWERS</div><div class="message-body"><div class="loading"><span class="dot"></span><span class="dot"></span><span class="dot"></span> Thinking…</div></div></article>' : '');
}

async function settings() {
  const stored = await chrome.storage.local.get(null);
  return Object.assign({
    theme:"ivory-gold", targetLanguage:"English", answerLanguage:"Auto-detect", topic:"school", difficulty:"Simple", teachingLevel:"normal", provider:"local",
    endpoint:"", model:"", apiKey:"", saveHistory:true, confirmExternal:true, allowExternalOnce:false, answerOnly:false, introEnabled:true
  }, stored);
}
function normalizeCommonTypos(input) {
  const original = String(input || "");
  // Conservative typo handling: only replace a small set of unmistakable common words.
  // Names, numbers, URLs and unknown words are preserved rather than guessed.
  const map = {teh:"the", adn:"and", taht:"that", thier:"their", recieve:"receive", becuase:"because", seperate:"separate", definately:"definitely", langauge:"language", musci:"music", artis:"artist", explan:"explain", explane:"explain", whta:"what", waht:"what", wher:"where", wierd:"weird", dont:"don't", doesnt:"doesn't", cant:"can't", wont:"won't", pls:"please", plz:"please", wat:"what", nieuuw:"nieuw", waaarom:"waarom", meschien:"misschien", interresant:"interessant", muziekek:"muziek"};
  const corrected = original.replace(/\b[\p{L}']+\b/gu, word => { const key=word.toLocaleLowerCase(); const replacement=map[key]; if(!replacement)return word; return word[0]===word[0].toUpperCase()?replacement[0].toUpperCase()+replacement.slice(1):replacement; });
  return {original, text:corrected, changed:corrected!==original};
}
function setSelected(text) {
  selected = String(text || "").slice(0, 12000);
  const el = $("selectionText");
  el.textContent = selected || "Select text on a webpage, then choose Ask, Explain, or Translate.";
  el.classList.toggle("empty", !selected);
}
function setAction(next) {
  action = next;
  document.querySelectorAll("[data-action]").forEach(el => el.classList.toggle("active", el.dataset.action === action));
}
async function runAnalysis(input, chosenAction = action, isFollowup = false) {
  if (busy) return;
  const text = String(input || "").trim();
  if (!text) { $("status").textContent = "Select text or enter a question first."; return; }
  if (!isFollowup) setSelected(text);
  busy = true; $("sendBtn").disabled = true; $("status").textContent = "";
  lastUserPrompt = text;
  const visibleMessages = [...history, {role:"user", content:text}];
  $("answer").innerHTML = renderConversation(visibleMessages, true);
  $("answer").querySelectorAll('[data-suggestion]').forEach(btn => btn.addEventListener('click', () => { $("question").value = btn.dataset.suggestion; $("question").focus(); }));
  try {
    const config = await settings();
    config.topic = $("topicSelect").value || config.topic || "auto";
    config.answerLanguage = $("answerLanguage").value || config.answerLanguage || "Auto-detect";
    config.teachingLevel = $("teachingLevel").value || config.teachingLevel || "normal";
    const typoResult = normalizeCommonTypos(text);
    const result = await window.WGA.analyze(typoResult.text, chosenAction, config, history);
    if (typoResult.changed) result.text = `> Possible typo adjustment: “${typoResult.original}” → “${typoResult.text}”\n\n${result.text}`;
    if (config.answerLanguage && config.answerLanguage !== "Auto-detect" && config.answerLanguage !== "English" && result.text && !result.externalBlocked) {
      const translated = await chrome.runtime.sendMessage({type:"WGA_TRANSLATE_TEXT", text:result.text, targetLanguage:config.answerLanguage}).catch(()=>null);
      if (translated?.ok && translated.text) result.text = translated.text + `\n\n---\n*Translated to ${config.answerLanguage} using a free public translation service. Review important wording.*`;
    }
    if (result.externalBlocked) {
      $("answer").innerHTML = renderConversation([...history, {role:"user",content:text}], false) + `<article class="chat-message from-tutor"><div class="message-author">PERMISSION NEEDED</div><div class="message-body">${renderMarkdown(result.text)}<p><button id="enableExternal" class="mini-btn">Allow this request</button></p></div></article>`;
      $("enableExternal").addEventListener("click", async () => {
        await chrome.storage.local.set({ allowExternalOnce: true });
        runAnalysis(text, chosenAction, isFollowup);
      });
      return;
    }
    lastAnswer = result.text;
    history.push({role:"user",content:text},{role:"assistant",content:result.text});
    history = history.slice(-16);
    $("answer").innerHTML = renderConversation(history);
    $("answer").querySelectorAll('[data-suggestion]').forEach(btn => btn.addEventListener('click', () => { $("question").value = btn.dataset.suggestion; $("question").focus(); }));
    if (config.saveHistory) await chrome.storage.local.set({ lastHistory: history });
    $("providerStatus").textContent = result.cached ? `Instant · ${result.source}` : (result.external ? `Connected · ${config.model}` : (result.source || "Free mode · public sources"));
  } catch (err) {
    const failure = `## Couldn't get an answer\n\n${err.message || "Something went wrong."}\n\nCheck Settings and your connection, then try again.`;
    $("answer").innerHTML = renderConversation([...history, {role:"user",content:text}, {role:"assistant",content:failure}]);
    $("status").textContent = "Request failed. Your selected text is still available.";
  } finally {
    busy = false; $("sendBtn").disabled = false;
  }
}
async function consumePending() {
  const pending = await chrome.runtime.sendMessage({type:"WGA_GET_PENDING"}).catch(() => ({}));
  if (pending?.pendingSelection) {
    setSelected(pending.pendingSelection);
    setAction(pending.pendingAction || "ask");
    await chrome.runtime.sendMessage({type:"WGA_CLEAR_PENDING"});
    runAnalysis(pending.pendingSelection, action);
  }
}
document.querySelectorAll(".action").forEach(btn => btn.addEventListener("click", () => {
  setAction(btn.dataset.action);
  if (selected) runAnalysis(selected, action);
}));
document.querySelectorAll("[data-suggestion]").forEach(btn => btn.addEventListener("click", () => {
  $("question").value = btn.dataset.suggestion;
  $("question").focus();
}));
$("sendBtn").addEventListener("click", () => {
  const q = $("question").value.trim();
  const combined = q || selected;
  $("question").value = "";
  runAnalysis(combined, q ? "ask" : action, Boolean(q));
});
$("question").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("sendBtn").click(); } });
$("copyBtn").addEventListener("click", async () => {
  const text = lastAnswer || $("answer").innerText;
  if (!text) return;
  try { await navigator.clipboard.writeText(text); $("status").textContent = "Answer copied."; }
  catch { $("status").textContent = "Copy failed. Select the answer and copy it manually."; }
});
$("regenBtn").addEventListener("click", () => (lastUserPrompt || selected) && runAnalysis(lastUserPrompt || selected, action));
$("clearBtn").addEventListener("click", async () => {
  selected = ""; history = []; lastAnswer = ""; lastUserPrompt = ""; setSelected("");
  $("answer").innerHTML = renderConversation([]);
  $("question").value = ""; $("status").textContent = "";
  await chrome.storage.local.remove("lastHistory");
});
$("editSelection").addEventListener("click", () => {
  const edited = prompt("Edit selected text:", selected);
  if (edited !== null) setSelected(edited);
});
$("topicSelect").addEventListener("change", async () => chrome.storage.local.set({topic:$("topicSelect").value}));
$("answerLanguage").addEventListener("change", async () => chrome.storage.local.set({answerLanguage:$("answerLanguage").value}));
$("teachingLevel").addEventListener("change", async () => chrome.storage.local.set({teachingLevel:$("teachingLevel").value}));
$("replayIntroBtn").addEventListener("click", () => { window.location.href = chrome.runtime.getURL("welcome.html"); });
$("settingsBtn").addEventListener("click", () => chrome.runtime.openOptionsPage());
async function refreshPanelPositionLabel() {
  const btn = $("panelPositionBtn");
  if (!btn) return;
  try {
    if (chrome.sidePanel?.getLayout) {
      const layout = await chrome.sidePanel.getLayout();
      const side = layout?.side || "right";
      btn.textContent = side === "left" ? "⇄ Left" : "⇄ Right";
      btn.title = `Chrome side panel is currently on the ${side}. Click for Chrome's position setting.`;
    } else {
      btn.textContent = "⇄ Panel";
      btn.title = "Chrome controls the native side-panel position in browser settings.";
    }
  } catch { btn.textContent = "⇄ Panel"; }
}
$("panelPositionBtn")?.addEventListener("click", async () => {
  $("status").textContent = "Chrome controls the built-in panel side. In Appearance settings, find Side panel position and choose Left or Right.";
  try { await chrome.tabs.create({url:"chrome://settings/appearance", active:true}); }
  catch { $("status").textContent += " If that tab did not open, open Chrome Settings → Appearance manually."; }
});
$("answerOnlyBtn").addEventListener("click", async () => { const enabled = !document.body.classList.contains("answer-only"); document.body.classList.toggle("answer-only", enabled); $("answerOnlyBtn").setAttribute("aria-pressed", String(enabled)); await chrome.storage.local.set({answerOnly: enabled}); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.theme) applyTheme(changes.theme.newValue);
});
function applyTheme(theme) {
  document.body.classList.toggle("dark", theme === "dark-gold" || theme === "dark");
  document.body.classList.toggle("white", theme === "white");
  document.documentElement.dataset.theme = theme || "ivory-gold";
}
(async () => {
  const config = await settings();
  applyTheme(config.theme);
  const logo = document.querySelector('.topbar img');
  if (logo) logo.addEventListener('error', () => { logo.style.display = 'none'; const mark = document.createElement('span'); mark.className = 'logo-fallback'; mark.textContent = '✦'; mark.setAttribute('aria-label','Write Get Answers'); logo.before(mark); }, {once:true});
  $("topicSelect").value = config.topic || "auto";
  $("answerLanguage").value = config.answerLanguage || "Auto-detect";
  $("teachingLevel").value = config.teachingLevel || "normal";
  if (config.answerOnly) { document.body.classList.add("answer-only"); $("answerOnlyBtn").setAttribute("aria-pressed", "true"); }
  history = config.saveHistory ? (await chrome.storage.local.get("lastHistory")).lastHistory || [] : [];
  if (history.length) {
    lastAnswer = [...history].reverse().find(item => item.role === 'assistant')?.content || '';
    lastUserPrompt = [...history].reverse().find(item => item.role === 'user')?.content || '';
    $("answer").innerHTML = renderConversation(history);
  }
  await refreshPanelPositionLabel();
  $("providerStatus").textContent = config.provider === "openai-compatible" && config.endpoint && config.model && config.apiKey ? `Configured · ${config.model}` : "Free mode · multi-source research";
  await consumePending();
  // A selection sent from the popup/content script can arrive after panel initialization.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "session" && changes.pendingSelection?.newValue) consumePending();
  });
})();