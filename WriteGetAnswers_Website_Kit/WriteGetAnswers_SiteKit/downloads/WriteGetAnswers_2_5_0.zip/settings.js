
const settingsLogo = document.querySelector('.masthead img');
if (settingsLogo) settingsLogo.addEventListener('error', () => {
  settingsLogo.style.display = 'none';
  const mark = document.createElement('span');
  mark.className = 'hero-mark'; mark.textContent = 'WGA';
  mark.setAttribute('aria-label', 'Write Get Answers');
  settingsLogo.before(mark);
}, { once: true });
const $ = id => document.getElementById(id);
const basicIds = ["theme","teachingLevel","difficulty","targetLanguage","answerLanguage","topic","provider","endpoint","model","apiKey","confirmExternal","saveHistory","introEnabled"];
const allPrefs = (window.WGA_PREFS || []).flatMap(group => group.items);
const preferenceKeys = allPrefs.map(pref => pref.key);
function renderPreferences() {
  const host = $("preferencesRoot");
  host.innerHTML = "";
  for (const group of (window.WGA_PREFS || [])) {
    const section = document.createElement("details");
    section.className = "pref-group";
    section.open = false;
    const summary = document.createElement("summary");
    const amount = document.createElement("span"); amount.textContent = `${group.items.length} settings`;
    const label = document.createElement("span"); label.textContent = group.category;
    summary.append(label, amount); section.append(summary);
    const grid = document.createElement("div"); grid.className = "pref-grid";
    for (const pref of group.items) {
      const labelEl = document.createElement("label"); labelEl.className = "pref-item"; labelEl.dataset.search = `${pref.label} ${pref.instruction} ${group.category}`.toLowerCase();
      const input = document.createElement("input"); input.type = "checkbox"; input.id = pref.key; input.dataset.pref = "true";
      const copy = document.createElement("span"); copy.className = "pref-copy";
      const strong = document.createElement("strong"); strong.textContent = pref.label;
      const small = document.createElement("small"); small.textContent = pref.instruction;
      copy.append(strong, small); labelEl.append(input, copy); grid.append(labelEl);
    }
    section.append(grid); host.append(section);
  }
}
async function load() {
  const data = await chrome.storage.local.get(null);
  const defaults = {theme:"ivory-gold",teachingLevel:"normal",difficulty:"Simple",targetLanguage:"English",answerLanguage:"Auto-detect",topic:"school",provider:"local",endpoint:"",model:"",apiKey:"",confirmExternal:true,saveHistory:true,introEnabled:true};
  for (const [k,v] of Object.entries(defaults)) if (data[k] === undefined) data[k] = v;
  if (data.theme === "light") data.theme = "ivory-gold";
  if (data.theme === "dark") data.theme = "dark-gold";
  for (const id of basicIds) {
    const el = $(id); if (!el) continue;
    if (el.type === "checkbox") el.checked = Boolean(data[id]); else el.value = data[id] ?? "";
  }
  for (const pref of allPrefs) $(pref.key).checked = data[pref.key] === undefined ? Boolean(pref.defaultValue) : Boolean(data[pref.key]);
}
async function save() {
  const data = {};
  for (const id of basicIds) { const el = $(id); data[id] = el.type === "checkbox" ? el.checked : el.value.trim(); }
  for (const pref of allPrefs) data[pref.key] = $(pref.key).checked;
  data.allowExternalOnce = false;
  await chrome.storage.local.set(data);
  $("status").textContent = "Saved. Your teacher mode and all 100 preferences are ready.";
  $("status").className = "success";
}
$("save").addEventListener("click", () => save().catch(err => { $("status").textContent = "Could not save: " + err.message; }));
$("resetPrefs").addEventListener("click", async () => {
  for (const pref of allPrefs) $(pref.key).checked = Boolean(pref.defaultValue);
  await save();
  $("status").textContent = "The 100 preferences have been reset to their recommended defaults.";
});
$("clear").addEventListener("click", async () => { await chrome.storage.local.remove(["lastHistory"]); $("status").textContent = "Saved conversation history cleared."; });
$("prefsSearch").addEventListener("input", () => {
  const q = $("prefsSearch").value.trim().toLowerCase();
  for (const group of $("preferencesRoot").querySelectorAll(".pref-group")) {
    let visible = 0;
    for (const item of group.querySelectorAll(".pref-item")) { const show = !q || item.dataset.search.includes(q); item.hidden = !show; if (show) visible++; }
    group.hidden = visible === 0;
    if (q && visible) group.open = true;
    if (!q) group.open = false;
  }
});
renderPreferences();
load().catch(err => { $("status").textContent = "Could not load settings: " + err.message; });
