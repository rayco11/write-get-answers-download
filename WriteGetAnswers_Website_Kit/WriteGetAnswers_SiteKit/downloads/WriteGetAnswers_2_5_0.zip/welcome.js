(() => {
  const scene = document.getElementById('scene');
  const headline = document.getElementById('headline');
  const subline = document.getElementById('subline');
  const progress = document.getElementById('progress');
  const logo = document.querySelector('.emblem img');
  logo?.addEventListener('error', () => {
    logo.style.display = 'none';
    const fallback = document.createElement('span'); fallback.className = 'logo-fallback'; fallback.textContent = '✦';
    logo.before(fallback);
  }, { once: true });
  const params = new URLSearchParams(window.location.search);
  const originTabId = Number(params.get('originTabId'));
  const originWindowId = Number(params.get('originWindowId'));
  const panelOpened = params.get('panelOpened') !== '0';
  let finished = false;
  function finishIntro() {
    if (finished) return;
    finished = true;
    scene.classList.add('fade-out');
    const skip = document.getElementById('skipIntro');
    if (skip) skip.disabled = true;
    window.setTimeout(() => {
      chrome.runtime.sendMessage({type:'WGA_FINISH_INTRO', originTabId, originWindowId, panelOpened}).then(response => {
        if (!response?.ok) window.location.replace(chrome.runtime.getURL('sidepanel.html'));
      }).catch(() => window.location.replace(chrome.runtime.getURL('sidepanel.html')));
    }, 700);
  }
  // Two-message, ten-second intro. Keep the timings in one place for easy tuning.
  window.setTimeout(() => {
    headline.innerHTML = '<span class="line">Thanks for using</span><span class="line gold">Write Get Answers.</span>';
    headline.querySelectorAll('.line').forEach((line, i) => {
      line.style.animation = 'none';
      void line.offsetWidth;
      line.style.animation = `textReveal .85s ${i ? '.25s' : '0s'} cubic-bezier(.2,.7,.2,1) forwards`;
    });
    subline.textContent = 'Your next great answer starts here.';
    subline.style.animation = 'none';
    void subline.offsetWidth;
    subline.style.animation = 'softIn .8s .45s forwards';
  }, 4800);
  window.setTimeout(finishIntro, 10000);
  const skip = document.getElementById('skipIntro');
  skip?.addEventListener('click', finishIntro);
  document.addEventListener('keydown', event => { if (event.key === 'Escape') finishIntro(); });
})();