const MENU_ID = "wga-ask-selection";
const LANGS = {English:"en",Dutch:"nl",German:"de",French:"fr",Spanish:"es",Italian:"it",Portuguese:"pt",Polish:"pl",Turkish:"tr",Arabic:"ar",Japanese:"ja",Korean:"ko",Chinese:"zh-CN",Hindi:"hi",Russian:"ru",Ukrainian:"uk",Swedish:"sv",Norwegian:"no",Danish:"da",Greek:"el",Hebrew:"he",Thai:"th",Vietnamese:"vi",Indonesian:"id",Czech:"cs",Romanian:"ro",Hungarian:"hu",Finnish:"fi",Persian:"fa",Bengali:"bn",Malay:"ms",Filipino:"tl"};

function safeNumber(n) { return Number.isInteger(n) ? String(n) : String(Number(n.toPrecision(11))); }
// Small arithmetic parser: no eval/Function and only numeric tokens/operators are accepted.
function calculate(raw) {
  let s = String(raw || "").trim().replace(/,/g, "").replace(/[×✕]/g, "*").replace(/(?<=\d)\s*[xX]\s*(?=\d)/g, "*").replace(/[÷:]/g, "/").replace(/[−–]/g, "-").replace(/\^/g, "^");
  if (!s || s.length > 120 || !/^[\d\s()+\-*/%.^]+$/.test(s) || !/\d/.test(s) || !/[+\-*/%^]/.test(s)) return null;
  const tokens = s.match(/\d+(?:\.\d+)?|[()+\-*/%^]/g) || [];
  if (tokens.join("").replace(/\s/g, "") !== s.replace(/\s/g, "")) return null;
  const out = [], ops = [], precedence = {"+":1,"-":1,"*":2,"/":2,"%":2,"^":3,"u-":4};
  let prev = "start";
  for (const t of tokens) {
    if (/^\d/.test(t)) { if (prev === "number" || prev === ")") return null; out.push(Number(t)); prev="number"; }
    else if (t === "(") { if (prev === "number" || prev === ")") return null; ops.push(t); prev="("; }
    else if (t === ")") { if (["start","operator","("].includes(prev)) return null; while(ops.length && ops.at(-1)!=="(") out.push(ops.pop()); if(ops.pop()!=="(") return null; prev=")"; }
    else {
      let op=t; if (t === "-" && ["start","operator","("].includes(prev)) op="u-";
      if (t === "+" && ["start","operator","("].includes(prev)) return null;
      if (op!=="u-" && ["start","operator","("].includes(prev)) return null;
      while(ops.length && ops.at(-1)!=="(" && (precedence[ops.at(-1)]>precedence[op] || (precedence[ops.at(-1)]===precedence[op] && op!=="^"))) out.push(ops.pop());
      ops.push(op); prev="operator";
    }
  }
  if (["start","operator","("].includes(prev)) return null;
  while(ops.length) { const op=ops.pop(); if(op==="(") return null; out.push(op); }
  const st=[];
  for(const t of out){ if(typeof t==="number"){st.push(t);continue;} if(t==="u-"){if(!st.length)return null;st.push(-st.pop());continue;} if(st.length<2)return null; const b=st.pop(),a=st.pop(); let v; if(t==="+")v=a+b;else if(t==="-")v=a-b;else if(t==="*")v=a*b;else if(t==="/")v=a/b;else if(t==="%")v=a%b;else if(t==="^")v=a**b; if(!Number.isFinite(v))return null; st.push(v); }
  return st.length===1 && Number.isFinite(st[0]) ? st[0] : null;
}
function stripHtml(s="") { return String(s).replace(/<[^>]*>/g," ").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/\s+/g," ").trim(); }
async function fetchJson(url, timeout=9000) {
  const response = await fetch(url, {signal: AbortSignal.timeout(timeout), headers:{"Accept":"application/json"}});
  if(!response.ok) throw new Error(`Source returned HTTP ${response.status}`);
  return response.json();
}
async function wikiResearch(query, lang="en") {
  const base = `https://${lang}.wikipedia.org/w/api.php`;
  const url = new URL(base); url.searchParams.set("action","query");url.searchParams.set("list","search");url.searchParams.set("srsearch",query.slice(0,280));url.searchParams.set("srlimit","5");url.searchParams.set("format","json");url.searchParams.set("origin","*");
  const data = await fetchJson(url.toString());
  const hits = data?.query?.search || [];
  // Fetch summaries concurrently to reduce perceived waiting time.
  return Promise.all(hits.slice(0,4).map(async hit => {
    const title=hit.title;
    let extract=stripHtml(hit.snippet||"");
    try {
      const summary=await fetchJson(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g,"_"))}`, 6000);
      extract=summary.extract||extract;
    } catch {}
    return {title,extract,url:`https://${lang}.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g,"_"))}`};
  }));
}
async function wikidataResearch(query) {
  const u = new URL("https://www.wikidata.org/w/api.php");
  u.searchParams.set("action", "wbsearchentities"); u.searchParams.set("search", query.slice(0, 180));
  u.searchParams.set("language", "en"); u.searchParams.set("uselang", "en"); u.searchParams.set("format", "json"); u.searchParams.set("limit", "4"); u.searchParams.set("origin", "*");
  const data = await fetchJson(u.toString());
  return (data.search || []).map(item => ({title:item.label || item.id, extract:item.description || "Wikidata entity record.", url:item.concepturi || `https://www.wikidata.org/wiki/${item.id}`, kind:"Wikidata"}));
}
async function openAlexResearch(query) {
  const u = new URL("https://api.openalex.org/works");
  u.searchParams.set("search", query.slice(0, 220)); u.searchParams.set("per-page", "4");
  u.searchParams.set("select", "id,doi,title,publication_year,authorships,primary_location,biblio");
  const data = await fetchJson(u.toString(), 7000);
  return (data.results || []).map(item => {
    const authors = (item.authorships || []).slice(0, 3).map(a => a.author?.display_name).filter(Boolean).join(", ");
    const venue = item.primary_location?.source?.display_name || "Scholarly work";
    return {title:item.title || "Untitled research", extract:[authors, item.publication_year, venue].filter(Boolean).join(" · ") || "Academic record. Open the record for details.", url:item.doi || item.id || `https://openalex.org/works?search=${encodeURIComponent(query)}`, kind:"OpenAlex scholarly index"};
  });
}
async function research(query, topic="auto", language="en") {
  const q=String(query||"").trim().slice(0,350);
  const results=[], errors=[];
  const jobs = [
    (async()=>{ const u=new URL("https://api.duckduckgo.com/");u.searchParams.set("q",q);u.searchParams.set("format","json");u.searchParams.set("no_html","1");u.searchParams.set("skip_disambig","1");const d=await fetchJson(u.toString()); const a=d.AbstractText||d.Answer||d.Definition; if(a)results.push({title:d.Heading||"DuckDuckGo instant answer",extract:a,url:d.AbstractURL||d.DefinitionURL||`https://duckduckgo.com/?q=${encodeURIComponent(q)}`,kind:"DuckDuckGo instant answer"}); for(const r of (d.RelatedTopics||[]).slice(0,3)){if(r.Text&&r.FirstURL)results.push({title:r.Text.split(" - ")[0].slice(0,100),extract:r.Text,url:r.FirstURL,kind:"DuckDuckGo related result"});}})().catch(e=>errors.push("DuckDuckGo: "+e.message)),
    (async()=>{const r=await wikiResearch(q, /^[a-z]{2}$/.test(language)?language:"en");results.push(...r.map(x=>({...x,kind:"Wikipedia"})));})().catch(e=>errors.push("Wikipedia: "+e.message)),
    (async()=>{const r=await wikidataResearch(q);results.push(...r);})().catch(e=>errors.push("Wikidata: "+e.message))
  ];
  if (["school","science","research","coding","history","general","auto"].includes(topic)) {
    jobs.push((async()=>{const r=await openAlexResearch(q);results.push(...r);})().catch(e=>errors.push("OpenAlex: "+e.message)));
  }
  await Promise.allSettled(jobs);
  const seen=new Set(), unique=results.filter(r=>{if(!r.url||seen.has(r.url))return false;seen.add(r.url);return true;}).slice(0,12);
  const searchLinks = [
    {title:"Google Search",url:`https://www.google.com/search?q=${encodeURIComponent(q)}`,kind:"Web search"},
    {title:"Bing Search",url:`https://www.bing.com/search?q=${encodeURIComponent(q)}`,kind:"Web search"},
    {title:"Brave Search",url:`https://search.brave.com/search?q=${encodeURIComponent(q)}`,kind:"Web search"}
  ];
  if (["school","science","research","history","auto"].includes(topic)) {
    searchLinks.push({title:"Khan Academy",url:`https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(q)}`,kind:"Lessons and practice"});
    searchLinks.push({title:"Google Scholar",url:`https://scholar.google.com/scholar?q=${encodeURIComponent(q)}`,kind:"Academic search"});
    searchLinks.push({title:"Wolfram|Alpha",url:`https://www.wolframalpha.com/input?i=${encodeURIComponent(q)}`,kind:"Computational answers"});
    searchLinks.push({title:"Quizlet",url:`https://quizlet.com/search?query=${encodeURIComponent(q)}&type=sets`,kind:"Study sets and flashcards"});
    searchLinks.push({title:"OpenStax",url:`https://openstax.org/subjects`,kind:"Free textbooks"});
  }
  return {results:unique,errors,searchLinks};
}
function formatResearch(query, data, topic="auto") {
  if(!data.results.length) {
    let out=`## I couldn't retrieve source summaries this time\n\nFree public endpoints may be unavailable, rate-limited, or unable to find a useful summary. I won't invent citations.\n\n## Search this topic directly\n\n`;
    for(const r of (data.searchLinks||[])) out+=`- **${r.title}** (${r.kind})\n  ${r.url}\n`;
    if(data.errors?.length) out+=`\n**Source status:** ${data.errors.join("; ")}\n`;
    return out;
  }
  const top=data.results[0];
  let out=`## Research brief\n\n**Question:** ${query}\n\n**Topic mode:** ${topic}\n\n${top.extract||"A related source was found, but it did not provide a summary."}\n\n## Sources and evidence\n\n`;
  data.results.forEach((r,i)=>{out+=`${i+1}. **${r.title}** — ${r.kind||"source"}\n   ${r.extract||"Open the source for details."}\n   Source: ${r.url}\n\n`;});
  out+=`## More places to check\n\n`;
  for(const r of (data.searchLinks||[])) out+=`- **${r.title}** (${r.kind})\n  ${r.url}\n`;
  if(topic==="school") out+=`\n## Learn it, don't just copy it\n\nFor schoolwork, use these results to understand the idea. Ask for worked steps, a simpler explanation, examples, and a quick practice question. Check your teacher's instructions before submitting AI-assisted work.\n`;
  out+=`\n## Reliability note\n\nThese are live results from selected free public endpoints plus direct search links, not a comprehensive crawl of the entire internet. Search links are provided for you to open; they are not represented as already-read sources. Check the original pages and compare more than one source for important claims.`;
  if(data.errors?.length) out+=`\n\n*Some sources were unavailable: ${data.errors.join("; ")}.*`;
  return out;
}
async function translateText(text, targetLanguage) {
  const target=LANGS[targetLanguage]||"en";
  const input=String(text||"").trim();
  if(!input) return {ok:false};
  // Public translation endpoint has short query limits. Translate paragraph-sized chunks conservatively.
  const chunks=[];
  for (const paragraph of input.split(/\n{2,}/)) {
    if (paragraph.length <= 420) { chunks.push(paragraph); continue; }
    let rest=paragraph;
    while(rest.length>420) {
      let cut=rest.lastIndexOf(" ",420); if(cut<180) cut=420;
      chunks.push(rest.slice(0,cut)); rest=rest.slice(cut).trim();
    }
    if(rest) chunks.push(rest);
  }
  const translated=[];
  for (const chunk of chunks) {
    let result="";
    for(const source of ["autodetect","en","nl","de","fr","es"]) {
      try { const u=new URL("https://api.mymemory.translated.net/get");u.searchParams.set("q",chunk);u.searchParams.set("langpair",`${source}|${target}`);const d=await fetchJson(u.toString());const value=d?.responseData?.translatedText;if(value&&d.responseStatus===200&&value.toLowerCase()!==chunk.toLowerCase()){result=value;break;} } catch {}
    }
    if(!result) return {ok:false};
    translated.push(result);
  }
  return {ok:true,text:translated.join("\n\n")};
}
async function freeAnswerUncached(text, action="ask", targetLanguage="English", topic="auto", answerLanguage="Auto-detect", teachingLevel="normal") {
  const q=String(text||"").trim().slice(0,12000);
  if(!q)return {text:"Select text or type a question first.",source:"local"};
  const math=calculate(q);
  if(math!==null && ["ask","explain","math","research"].includes(action)) {
    const colonDivision = /^\s*\d+(?:\.\d+)?\s*:\s*\d+(?:\.\d+)?\s*$/.test(q);
    let steps;
    if (colonDivision) {
      const [left,right] = q.split(":").map(v=>Number(v.trim()));
      if (teachingLevel === "child") {
        steps = `In school maths, **:** means “divide by” here — it is not a clock time.\n\nImagine you have ${left} sweets and share them equally between ${right} friends. Each friend gets **${safeNumber(math)}** sweets.\n\n1. Rewrite ${q} as ${left} ÷ ${right}.\n2. Count how many groups of ${right} fit into ${left}.\n3. ${left} ÷ ${right} = **${safeNumber(math)}**.`;
      } else {
        steps = `In this school-maths expression, **:** is the division symbol, not a time separator.\n\n1. Rewrite ${q} as ${left} ÷ ${right}.\n2. Calculate ${left} ÷ ${right} = **${safeNumber(math)}**.\n3. Check: ${safeNumber(math)} × ${right} = ${left}. The result is correct.`;
      }
    } else {
      steps = `The calculation follows the usual order of operations: parentheses, powers, multiplication/division, then addition/subtraction.\n\n**Check your answer:** estimate the result or substitute the answer back into the original expression.`;
      if (teachingLevel === "child") steps = `Let's do it one step at a time. The answer is **${safeNumber(math)}**. We follow maths rules in order: brackets first, then powers, then multiply or divide, and finally add or subtract. Try checking the answer by doing the calculation again slowly.`;
    }
    return {source:"Local school-maths tutor",text:`## Answer: ${safeNumber(math)}\n\n### Teacher's explanation\n${steps}\n\n*Calculated locally in your browser. No API key or external service was used.*`};
  }
  if(action==="translate"){
    const target=LANGS[targetLanguage]||"en"; const candidates=["autodetect","en","nl","de","fr","es"];
    for(const source of candidates){try{const u=new URL("https://api.mymemory.translated.net/get");u.searchParams.set("q",q.slice(0,450));u.searchParams.set("langpair",`${source}|${target}`);const d=await fetchJson(u.toString());const translated=d?.responseData?.translatedText;if(translated&&d.responseStatus===200&&translated.toLowerCase()!==q.toLowerCase())return {source:"MyMemory free translation",text:`## Translation · ${targetLanguage}\n\n${translated}\n\n### Original text\n${q}\n\n*Free public translation service. Check nuance and names for important translations.*`};}catch{}}
    return {source:"Translation service unavailable",text:`## Translation unavailable\n\nThe free public translation service did not return a reliable result. Try a shorter selection or check your connection.\n\n**Target language:** ${targetLanguage}\n\n**Original text:** ${q}`};
  }
  if(action==="research" || action==="ask" || action==="explain"){
    const data=await research(q, topic, LANGS[answerLanguage] || "en");
    if(data.results.length || action==="research") return {source:"Free multi-source research",text:formatResearch(q,data,topic),results:data.results};
  }
  if(action==="summarize"){
    const sentences=q.match(/[^.!?]+[.!?]+|[^.!?]+$/g)||[q];
    const summary=sentences.length<=3?q:sentences.slice(0,3).join(" ").trim()+"…";
    return {source:"Local text summary",text:`## Quick extractive summary\n\n${summary}\n\n*This is a simple local summary based on the text's opening sentences, not a full AI-generated summary.*`};
  }
  if(action==="explain") return {source:"Local fallback",text:`## Explanation needs a stronger engine\n\nI couldn't find a trustworthy public summary for **${q}**.\n\nTo avoid giving you made-up facts, I haven't invented an explanation. Try **Research** to see related source results, or open this search: https://www.google.com/search?q=${encodeURIComponent(q)}`};
  return {source:"Free research fallback",text:`## I couldn't verify a direct answer\n\nI searched free public sources but couldn't retrieve a reliable direct answer for this exact text.\n\n**Try research:** use the Research action or search directly: https://www.google.com/search?q=${encodeURIComponent(q)}\n\n*This no-key version uses local tools and public endpoints. It is not a full AI model and won't know everything.*`};
}


// Short-lived in-memory cache: repeated questions return instantly without persisting queries.
const answerCache = new Map();
async function freeAnswer(text, action="ask", targetLanguage="English", topic="auto", answerLanguage="Auto-detect", teachingLevel="normal") {
  const key = JSON.stringify([String(text||"").trim(), action, targetLanguage, topic, answerLanguage, teachingLevel]);
  const now = Date.now();
  const cached = answerCache.get(key);
  if (cached && now - cached.time < 120000) return {...cached.value, cached:true, source:`Cached · ${cached.value.source || "local result"}`};
  const value = await freeAnswerUncached(text, action, targetLanguage, topic, answerLanguage, teachingLevel);
  if (answerCache.size >= 35) answerCache.delete(answerCache.keys().next().value);
  answerCache.set(key, {time: now, value});
  return value;
}

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => chrome.contextMenus.create({id:MENU_ID,title:"Research / answer with Write Get Answers",contexts:["selection"]}));
  await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:false}).catch(()=>{});
  const defaults={theme:"ivory-gold",targetLanguage:"English",answerLanguage:"Auto-detect",topic:"school",difficulty:"Simple",teachingLevel:"normal",defaultAction:"research",provider:"local",endpoint:"",model:"",apiKey:"",saveHistory:true,confirmExternal:true,answerOnly:false, introEnabled:true};
  const current=await chrome.storage.local.get(Object.keys(defaults));const missing={};for(const [k,v] of Object.entries(defaults))if(current[k]===undefined)missing[k]=v;if(Object.keys(missing).length)await chrome.storage.local.set(missing);
});
async function openPanel(tabId){try{await chrome.sidePanel.open({tabId});}catch(err){console.warn("Could not open side panel:",err);}}
chrome.contextMenus.onClicked.addListener(async(info,tab)=>{if(info.menuItemId!==MENU_ID||!tab?.id)return;const text=(info.selectionText||"").trim();if(text)await chrome.storage.session.set({pendingSelection:text,pendingAction:"research"});await openPanel(tab.id);});
chrome.action.onClicked.addListener(tab=>{
  // Call open() immediately during the user gesture. The welcome tab is only a cinematic intro;
  // finishing it closes that tab and returns to this original webpage with the real side panel open.
  const panelPromise = tab?.id
    ? chrome.sidePanel.open({tabId:tab.id}).then(()=>true).catch(err=>{console.warn("Side panel could not open:",err);return false;})
    : Promise.resolve(false);
  (async()=>{
    try {
      const launch = await chrome.storage.local.get({introEnabled:true});
      const opened = await panelPromise;
      if (launch.introEnabled && tab?.id) {
        const params = new URLSearchParams({originTabId:String(tab.id), originWindowId:String(tab.windowId ?? ""), panelOpened:opened ? "1" : "0"});
        await chrome.tabs.create({url: chrome.runtime.getURL(`welcome.html?${params.toString()}`), active:true});
      } else if (!opened && tab?.id) {
        await chrome.tabs.create({url:chrome.runtime.getURL("sidepanel.html"), active:true});
      }
    } catch (err) {
      console.warn("Could not launch Write Get Answers:",err);
      if(tab?.id) await chrome.tabs.create({url:chrome.runtime.getURL("sidepanel.html"), active:true}).catch(()=>{});
    }
  })();
});
chrome.commands.onCommand.addListener(async command=>{if(command!=="open-assistant")return;const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(tab?.id)await openPanel(tab.id);});
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{(async()=>{
  if(message?.type==="WGA_FINISH_INTRO"){
    const ownPrefix = chrome.runtime.getURL("welcome.html");
    if (!sender.url || !sender.url.startsWith(ownPrefix) || !sender.tab?.id) { sendResponse({ok:false,error:"Invalid intro sender"}); return; }
    const welcomeTabId = sender.tab.id;
    const originTabId = Number(message.originTabId);
    const originWindowId = Number(message.originWindowId);
    // If Chrome rejected sidePanel.open (e.g. a restricted browser page), keep the intro tab
    // and turn it into the full assistant rather than closing the only usable interface.
    if (message.panelOpened === false) {
      sendResponse({ok:true,fallback:true});
      chrome.tabs.update(welcomeTabId,{url:chrome.runtime.getURL("sidepanel.html")}).catch(err=>console.warn("Could not open fallback assistant:",err));
      return;
    }
    // Respond before closing the tab carrying this message, then clean up asynchronously.
    sendResponse({ok:true});
    (async()=>{
      try { await chrome.tabs.remove(welcomeTabId); } catch {}
      if (Number.isInteger(originTabId) && originTabId > 0) {
        try { await chrome.tabs.update(originTabId,{active:true}); } catch {}
        if (Number.isInteger(originWindowId) && originWindowId > 0) { try { await chrome.windows.update(originWindowId,{focused:true}); } catch {} }
      }
    })().catch(err=>console.warn("Could not return to the original webpage:",err));
    return;
  }
  if(message?.type==="WGA_TRANSLATE_TEXT"){sendResponse(await translateText(message.text,message.targetLanguage));return;}
  if(message?.type==="WGA_FREE_ANSWER"){sendResponse({ok:true,...await freeAnswer(message.text,message.action||"ask",message.targetLanguage||"English",message.topic||"auto",message.answerLanguage||"Auto-detect",message.teachingLevel||"normal")});return;}
  if(message?.type==="WGA_SELECTION"){await chrome.storage.session.set({pendingSelection:String(message.text||"").slice(0,12000),pendingAction:message.action||"research"});sendResponse({ok:true});return;}
  if(message?.type==="WGA_OPEN_PANEL"){const id=sender.tab?.id??message.tabId;if(id)await openPanel(id);sendResponse({ok:true});return;}
  if(message?.type==="WGA_GET_PENDING"){sendResponse(await chrome.storage.session.get(["pendingSelection","pendingAction"]));return;}
  if(message?.type==="WGA_CLEAR_PENDING"){await chrome.storage.session.remove(["pendingSelection","pendingAction"]);sendResponse({ok:true});return;}
  sendResponse({ok:false,error:"Unknown message"});
})().catch(error=>sendResponse({ok:false,error:String(error)}));return true;});
