(() => {
  const WGA = window.WGA || (window.WGA = {});
  const safeText = value => String(value || "").trim().slice(0, 12000);

  function localMath(raw) { return null; }

  function localFallback(text, action, settings) {
    const source = safeText(text);
    if (!source) return "Select some text on a webpage first, or type a question below.";
    if (action === "translate") {
      return `## Translation needs a language engine\n\nSelected text:\n\n> ${source}\n\nChoose a configured AI provider in Settings to translate into **${settings.targetLanguage || "English"}**. The extension does not pretend to translate accurately without a translation engine.`;
    }
    const math = localMath(source);
    if (math && ["ask", "math", "explain"].includes(action)) return math;
    if (action === "summarize") {
      const sentences = source.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [source];
      const short = sentences.slice(0, 3).join(" ").trim();
      return `## Quick summary\n\n${short}${sentences.length > 3 ? "…" : ""}\n\n*This offline fallback extracts an opening summary; configure an AI provider for a more complete summary.*`;
    }
    if (action === "rewrite" || action === "grammar") {
      return `## Selected text\n\n${source}\n\n## Writing help\n\nA configured AI provider is needed for reliable grammar correction or rewriting. You can copy this text and ask for a simpler, clearer, more formal, or more professional version once a provider is configured.`;
    }
    if (action === "explain") {
      return `## Let's break it down\n\n**Selected text:** ${source}\n\nI can show the text and explain supported calculations locally. For a full explanation of this topic, connect an AI provider in Settings.`;
    }
    return `## Write Get Answers\n\n**Selected text:** ${source}\n\nYour extension is working. For general knowledge answers, detailed explanations, translations, coding help, and current research, configure an AI provider in Settings. Basic supported calculations and simple summaries can work locally.`;
  }

  async function analyze(text, action, settings, history = []) {
    const source = safeText(text);
    if (settings.provider === "openai-compatible" && settings.endpoint && settings.model && settings.apiKey) {
      if (settings.confirmExternal && !settings.allowExternalOnce) {
        return { text: "## External AI confirmation\n\nYour selected text may be sent to the AI provider configured in Settings. Review the provider and privacy options there, then enable external requests to continue.", externalBlocked: true };
      }
      const endpoint = settings.endpoint.trim().replace(/\/+$/, "");
      const url = endpoint.endsWith("/chat/completions") ? endpoint : endpoint + "/chat/completions";
      const actionInstructions = {
        ask: "Answer the selected question directly, then explain how the answer works. Give useful examples and tips. Be clear about uncertainty and never invent sources.",
        research: "Research this topic using only the sources actually supplied by available tools. Cite source URLs and distinguish verified information from uncertainty.",
        explain: "Explain the selected text in simple language, define important terms, and give an example.",
        translate: `Translate the selected text into ${settings.targetLanguage || "English"}. Preserve meaning and formatting. Return the translation first.`,
        summarize: "Summarize the selected text accurately. Preserve key facts and do not add unsupported claims.",
        rewrite: "Rewrite the selected text to be clearer and more polished while preserving meaning.",
        grammar: "Correct grammar and spelling. Show the corrected text and briefly explain important changes."
      };
      const enabledPrefs = (window.WGA_PREFS || []).flatMap(group => group.items).filter(pref => settings[pref.key] ?? pref.defaultValue).map(pref => pref.instruction);
      const teachingModes = {
        child: "Teach like a patient teacher explaining to a curious seven-year-old: use short sentences and familiar examples, but do not talk down to the learner.",
        normal: "Teach clearly at a normal school level: define new terms, explain the steps, and give a useful example where appropriate.",
        exam: "Use exam-prep mode: precise definitions, complete worked steps, key formulas, common mistakes, and a quick answer check."
      };
      const messages = [
        { role: "system", content: `You are Write Get Answers, a patient, accurate school teacher and research tutor. Difficulty: ${settings.difficulty || "Simple"}. Teaching mode: ${teachingModes[settings.teachingLevel] || teachingModes.normal}. Topic focus: ${settings.topic || "auto-detect"}. Answer language: ${settings.answerLanguage || "Auto-detect (reply in the user’s language)"}. Interpret misspellings, informal wording, mixed languages, and likely intended meanings conservatively; if a typo makes the request ambiguous, ask a short clarification instead of guessing. For schoolwork, prefer explanation and worked reasoning over a bare answer. For music questions, distinguish artists, songs, albums, genres, and music theory. Action: ${actionInstructions[action] || actionInstructions.ask} User answer preferences: ${enabledPrefs.join(" ")} Be accurate, transparent about uncertainty, and structure answers with headings and bullets when useful. Do not claim to have browsed the web unless tools actually provide that capability.` },
        ...history.slice(-8).filter(m => ["user", "assistant"].includes(m.role)).map(m => ({ role: m.role, content: String(m.content).slice(0, 5000) })),
        { role: "user", content: source }
      ];
      const headers = { "Content-Type": "application/json", "Authorization": `Bearer ${settings.apiKey}` };
      const response = await fetch(url, {
        method: "POST", headers,
        body: JSON.stringify({ model: settings.model, messages, temperature: 0.4 }),
        signal: AbortSignal.timeout(45000)
      });
      if (!response.ok) {
        const detail = await response.text().catch(() => "");
        throw new Error(`AI provider returned ${response.status}${detail ? ": " + detail.slice(0, 180) : ""}`);
      }
      const data = await response.json();
      const answer = data?.choices?.[0]?.message?.content;
      if (!answer) throw new Error("The provider returned no answer. Check the endpoint and model settings.");
      return { text: answer, external: true };
    }
    const free = await chrome.runtime.sendMessage({
      type: "WGA_FREE_ANSWER", text: source, action,
      targetLanguage: settings.targetLanguage || "English", topic: settings.topic || "auto", answerLanguage: settings.answerLanguage || "Auto-detect", teachingLevel: settings.teachingLevel || "normal"
    }).catch(() => null);
    if (free?.ok && free.text) return { text: free.text, external: false, source: free.source };
    return { text: localFallback(source, action, settings), external: false };
  }

  WGA.analyze = analyze;
})();