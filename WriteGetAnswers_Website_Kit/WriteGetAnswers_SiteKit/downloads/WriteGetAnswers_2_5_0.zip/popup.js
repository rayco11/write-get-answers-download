const $ = id => document.getElementById(id);
async function openPanel(action) {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id) { $("status").textContent = "No active tab found."; return; }
  try {
    if (action) {
      let text = "";
      try {
        const result = await chrome.scripting.executeScript({
          target:{tabId:tab.id}, func:() => {
            const a = document.activeElement;
            if (a && (a.tagName === "TEXTAREA" || a.tagName === "INPUT") && a.selectionStart != null && a.selectionEnd > a.selectionStart) return a.value.slice(a.selectionStart,a.selectionEnd);
            return window.getSelection()?.toString() || "";
          }
        });
        text = (result?.[0]?.result || "").trim();
      } catch {}
      if (text) await chrome.storage.session.set({pendingSelection:text.slice(0,12000),pendingAction:action});
      else $("status").textContent = "No selected text detected. Select text on the webpage first.";
    }
    await chrome.sidePanel.open({tabId:tab.id});
    if (action && !$("status").textContent.startsWith("No selected")) $("status").textContent = "Assistant opened.";
  } catch (err) { $("status").textContent = "Couldn't open the panel on this page. Try a regular webpage."; }
}
$("open").addEventListener("click", () => openPanel());
$("explain").addEventListener("click", () => openPanel("explain"));
$("translate").addEventListener("click", () => openPanel("translate"));
$("research").addEventListener("click", () => openPanel("research"));
$("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());