(() => {
  if (window.__wgaInstalled) return;
  window.__wgaInstalled = true;
  let bubble = null, drawer = null, hideTimer = null, currentText = "", currentAction = "ask", busy = false;

  function selectedText() {
    const active = document.activeElement;
    if (active && (active.tagName === "TEXTAREA" || (active.tagName === "INPUT" && /^(text|search|url|email|tel)$/i.test(active.type)))) {
      const start = active.selectionStart, end = active.selectionEnd;
      if (start != null && end != null && end > start) return active.value.slice(start, end).trim();
    }
    return (window.getSelection()?.toString() || "").trim();
  }
  function removeBubble() { if (bubble) bubble.remove(); bubble = null; }
  function addStyle(el, styles) { Object.assign(el.style, styles); }
  function makeBubble(text, x, y) {
    removeBubble();
    if (!text) return;
    bubble = document.createElement("div");
    bubble.id = "wga-selection-bubble";
    bubble.innerHTML = '<button data-action="ask">✦ Ask</button><button data-action="explain">Explain</button><button data-action="translate">Translate</button><button data-action="research">⌕ Research</button>';
    addStyle(bubble, {position:"fixed",zIndex:"2147483647",left:Math.max(8,Math.min(x,innerWidth-238))+"px",top:Math.max(8,Math.min(y+12,innerHeight-50))+"px",display:"flex",gap:"4px",padding:"6px",background:"linear-gradient(135deg,#211909,#100f0b)",border:"1px solid #d6b24e",borderRadius:"12px",boxShadow:"0 8px 28px rgba(0,0,0,.3),0 0 18px rgba(214,178,78,.12)",font:"12px/1.2 system-ui,sans-serif"});
    bubble.querySelectorAll("button").forEach(btn => {
      addStyle(btn,{border:"0",borderRadius:"8px",padding:"8px 10px",color:"#f4e2ab",background:"transparent",cursor:"pointer",font:"600 12px system-ui",transition:"background .16s ease,transform .16s ease"});
      btn.addEventListener("mouseenter",()=>{btn.style.background="#473613";btn.style.transform="translateY(-1px)";});
      btn.addEventListener("mouseleave",()=>{btn.style.background="transparent";btn.style.transform="none";});
      btn.addEventListener("mousedown",e=>e.preventDefault());
      btn.addEventListener("click",async e=>{
        e.stopPropagation(); currentText=text; currentAction=btn.dataset.action;
        openDrawer(); setSelection(text); setAction(currentAction); removeBubble(); await analyze(text,currentAction);
      });
    });
    document.documentElement.appendChild(bubble);
    clearTimeout(hideTimer); hideTimer=setTimeout(removeBubble,12000);
  }
  function setSelection(text) {
    currentText=String(text||"").slice(0,12000);
    const preview=drawer?.querySelector("#wga-preview");
    if(preview){preview.textContent=currentText||"Select text on this webpage to get started.";preview.style.color=currentText?(drawer?.dataset.theme==='dark-gold'?'#ead99a':'#594515'):(drawer?.dataset.theme==='dark-gold'?'#b6a87e':'#847247');}
  }
  function setAction(action) {
    currentAction=action;
    drawer?.querySelectorAll("[data-wga-action]").forEach(b=>{
      const active=b.dataset.wgaAction===action;
      b.style.background=active?"#f8e5a8":"#fffdf6";b.style.color=active?"#513900":"#59430d";b.style.borderColor=active?"#c79a35":"#e2d2a2";
    });
  }
  function openDrawer() {
    if(drawer){drawer.style.display="flex";return}
    drawer=document.createElement("aside");drawer.id="wga-drawer";
    drawer.innerHTML=`<header id="wga-head"><img id="wga-logo" src="${chrome.runtime.getURL("assets/logo.jpg")}" alt=""/><div style="flex:1"><strong>Write Get Answers</strong><small style="display:block;color:#dfca87;font-size:11px;margin-top:3px">Free research · no API key</small></div><button id="wga-dock" title="Move helper to the left" aria-label="Move helper to the left">⇠</button><button id="wga-answer-only" title="Show only the answer" aria-pressed="false">▣</button><button id="wga-close" title="Close">×</button></header>
    <div id="wga-body"><div class="wga-label">SELECTED TEXT</div><div id="wga-preview">Select text on this webpage to get started.</div>
    <div id="wga-actions"><button data-wga-action="ask">✦ Ask</button><button data-wga-action="explain">Explain</button><button data-wga-action="translate">Translate</button><button data-wga-action="summarize">Summary</button><button data-wga-action="research">Research</button></div>
    <div class="wga-label" style="margin-top:18px">ANSWER</div><div id="wga-answer"><b>Ready when you are.</b><p>Select text on the page and click Ask, Explain, or Translate. Basic calculations run locally; free public services can answer some factual lookups and translations.</p></div><div id="wga-status" role="status"></div></div>
    <footer id="wga-footer"><select id="wga-language" aria-label="Translation target"><option>English</option><option>Dutch</option><option>German</option><option>French</option><option>Spanish</option><option>Italian</option><option>Portuguese</option><option>Polish</option><option>Turkish</option><option>Arabic</option><option>Japanese</option><option>Korean</option><option>Chinese</option></select><textarea id="wga-question" rows="2" placeholder="Ask a question or follow-up…"></textarea><div style="display:flex;gap:7px"><button id="wga-send">Get answer ↗</button><button id="wga-copy">Copy</button></div><small style="color:#829da4;display:block;margin-top:8px;font-size:10px">Public no-key services may process submitted text. Avoid sending private information.</small></footer>`;
    addStyle(drawer,{position:"fixed",top:"0",right:"0",width:"min(390px,94vw)",height:"100vh",zIndex:"2147483646",display:"flex",flexDirection:"column",background:"#faf7ed",color:"#292315",boxShadow:"-12px 0 38px rgba(55,35,0,.22),0 0 28px rgba(199,154,53,.08)",borderLeft:"1px solid #e0c778",font:"13px/1.5 system-ui,-apple-system,Segoe UI,sans-serif",transform:"translateX(14px)",opacity:"0",transition:"transform .22s ease,opacity .22s ease"});
    const style=document.createElement("style");style.textContent=`#wga-drawer *{box-sizing:border-box}#wga-drawer button,#wga-drawer select,#wga-drawer textarea{font:inherit}#wga-head{display:flex;align-items:center;gap:9px;padding:14px;background:linear-gradient(115deg,#211909,#100f0b 60%,#36270a);color:#fff3c9;border-bottom:1px solid #b89335;box-shadow:0 6px 18px #4d360d20}#wga-logo{width:38px;height:38px;object-fit:cover;border-radius:12px;background:#fff;border:1px solid #d7b65d;box-shadow:0 0 0 2px #e9d49b25}#wga-logo-fallback{display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,#fff1af,#b98318);color:#342400;font-size:22px}#wga-dock,#wga-answer-only{border:1px solid #6c5424;background:#ffffff0b;color:#f2d77d;border-radius:9px;min-width:31px;height:32px;cursor:pointer;transition:background .15s ease,transform .15s ease}#wga-dock:hover,#wga-answer-only:hover,#wga-close:hover{background:#4a3814;transform:translateY(-1px)}#wga-drawer.answer-only #wga-preview,#wga-drawer.answer-only #wga-actions,#wga-drawer.answer-only #wga-footer,#wga-drawer.answer-only .wga-label:first-child,#wga-drawer.answer-only #wga-status{display:none!important}#wga-drawer.answer-only #wga-body{display:flex;flex-direction:column}#wga-drawer.answer-only #wga-answer{flex:1;margin-top:0}#wga-answer-only[aria-pressed="true"]{background:#4a3814;color:#fff0ab}#wga-head strong{font-size:14px;letter-spacing:-.2px}#wga-close{border:1px solid #6c5424;background:#ffffff0b;color:#fff0bd;border-radius:9px;width:32px;height:32px;font-size:23px;cursor:pointer;transition:background .15s ease,transform .15s ease}#wga-body{padding:14px;overflow:auto;flex:1}#wga-preview{margin-top:7px;background:#fffdf6;color:#594515;border:1px solid #e4d4a2;border-radius:11px;padding:11px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:120px;overflow:auto;font-size:12px;box-shadow:inset 0 1px #fff}#wga-drawer .wga-label{font-size:10px;font-weight:850;letter-spacing:1px;color:#847247}#wga-actions{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:5px;margin-top:9px}#wga-actions button{padding:8px 2px;font-size:10px;font-weight:750;border:1px solid #e2d2a2;border-radius:8px;background:#fffdf6;color:#59430d;cursor:pointer;transition:transform .16s ease,box-shadow .16s ease}#wga-actions button:hover{transform:translateY(-1px);box-shadow:0 4px 12px #ad7e1c20}#wga-actions button[style*="rgb(255, 242, 194)"],#wga-actions button.active{background:#f8e5a8!important;color:#513900!important;border-color:#c79a35!important}#wga-answer{background:#fffdf7;border:1px solid #e3d5ae;border-radius:13px;padding:13px;margin-top:8px;min-height:190px;white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;line-height:1.65;box-shadow:0 4px 15px #7757190a;animation:wgaAnswerIn .24s ease both}#wga-answer a{color:#946816;text-decoration:underline;overflow-wrap:anywhere}#wga-answer h2,#wga-answer h3{margin:5px 0 9px;line-height:1.3}#wga-answer p{margin:7px 0}#wga-status{font-size:11px;color:#9a6816;margin-top:6px;min-height:16px}#wga-footer{padding:11px 12px;border-top:1px solid #e2d2a2;background:#fffdf6}#wga-language{width:100%;padding:8px;border:1px solid #dfd0a7;border-radius:8px;background:#faf6e9;margin-bottom:7px;color:#292315}#wga-question{width:100%;resize:vertical;padding:10px;border:1px solid #dfd0a7;border-radius:10px;background:#fff;color:#292315;min-height:46px}#wga-send{flex:1;background:linear-gradient(135deg,#f4d879,#bd861d);color:#2b1d00;border:1px solid #c79a35;border-radius:9px;padding:10px;font-weight:850;cursor:pointer;box-shadow:0 5px 14px #ad7e1c25}#wga-send:disabled{opacity:.6;cursor:wait}#wga-copy{background:#fffdf6;border:1px solid #dfd0a7;color:#59430d;border-radius:9px;padding:10px;cursor:pointer}#wga-drawer button:focus-visible,#wga-drawer textarea:focus-visible{outline:2px solid #d5aa43;outline-offset:2px}#wga-drawer .wga-loading{color:#8d722c}#wga-drawer .wga-small{font-size:11px;color:#718990}#wga-drawer[data-side="left"]{border-left:0!important;border-right:1px solid #e0c778!important;box-shadow:12px 0 38px rgba(55,35,0,.22),0 0 28px rgba(199,154,53,.08)!important}#wga-drawer[data-side="right"]{border-right:0!important;border-left:1px solid #e0c778!important;box-shadow:-12px 0 38px rgba(55,35,0,.22),0 0 28px rgba(199,154,53,.08)!important}#wga-drawer[data-theme="dark-gold"] #wga-body{background:#100f0b}#wga-drawer[data-theme="dark-gold"] #wga-preview{background:#19170f;color:#ead99a;border-color:#4b3c1c;box-shadow:none}#wga-drawer[data-theme="dark-gold"] #wga-answer{background:#19170f;color:#f3ebd2;border-color:#4b3c1c;box-shadow:none}#wga-drawer[data-theme="dark-gold"] #wga-footer{background:#19170f;border-color:#4b3c1c}#wga-drawer[data-theme="dark-gold"] #wga-language,#wga-drawer[data-theme="dark-gold"] #wga-question{background:#100f0b;color:#f3ebd2;border-color:#4b3c1c}#wga-drawer[data-theme="dark-gold"] #wga-actions button,#wga-drawer[data-theme="dark-gold"] #wga-copy{background:#19170f;color:#f3ebd2;border-color:#4b3c1c}#wga-drawer[data-theme="dark-gold"] .wga-label{color:#b6a87e}#wga-drawer[data-theme="white"] #wga-preview{background:#fff;color:#594515}#wga-drawer[data-theme="white"] #wga-answer,#wga-drawer[data-theme="white"] #wga-footer{background:#fff}@keyframes wgaAnswerIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){#wga-drawer,#wga-drawer *{transition:none!important;animation:none!important}}`;
    drawer.appendChild(style);document.documentElement.appendChild(drawer);
    const logo = drawer.querySelector('#wga-logo');
    logo.addEventListener('error',()=>{logo.style.display='none';const mark=document.createElement('span');mark.id='wga-logo-fallback';mark.textContent='✦';mark.setAttribute('aria-label','Write Get Answers');logo.before(mark);},{once:true});
    function applyDrawerSide(side, persist=true) {
      const resolved = side === 'left' ? 'left' : 'right';
      drawer.dataset.side = resolved;
      drawer.style.left = resolved === 'left' ? '0' : 'auto';
      drawer.style.right = resolved === 'right' ? '0' : 'auto';
      drawer.style.transform = 'translateX(' + (resolved === 'left' ? '-14px' : '14px') + ')';
      const dock = drawer.querySelector('#wga-dock');
      dock.textContent = resolved === 'left' ? '⇢' : '⇠';
      dock.title = resolved === 'left' ? 'Move helper to the right' : 'Move helper to the left';
      dock.setAttribute('aria-label', dock.title);
      requestAnimationFrame(()=>{if(drawer){drawer.style.opacity='1';drawer.style.transform='translateX(0)';}});
      if(persist) chrome.storage.local.set({drawerSide:resolved}).catch(()=>{});
    }
    function applyDrawerTheme(theme) {
      const resolved = theme === 'dark' || theme === 'dark-gold' ? 'dark-gold' : (theme === 'white' ? 'white' : 'ivory-gold');
      drawer.dataset.theme = resolved;
      drawer.style.background = resolved === 'dark-gold' ? '#100f0b' : (resolved === 'white' ? '#ffffff' : '#faf7ed');
      drawer.style.color = resolved === 'dark-gold' ? '#f3ebd2' : '#292315';
      const preview=drawer.querySelector('#wga-preview');
      if(preview) preview.style.color = currentText ? (resolved === 'dark-gold' ? '#ead99a' : '#594515') : (resolved === 'dark-gold' ? '#b6a87e' : '#847247');
    }
    chrome.storage.local.get({answerOnly:false,drawerSide:'right',theme:'ivory-gold'}).then(cfg=>{if(cfg.answerOnly){drawer.classList.add("answer-only");drawer.querySelector("#wga-answer-only").setAttribute("aria-pressed","true");}applyDrawerSide(cfg.drawerSide,false);applyDrawerTheme(cfg.theme);}).catch(()=>{applyDrawerSide('right',false);applyDrawerTheme('ivory-gold');});
    drawer.querySelector('#wga-dock').addEventListener('click',()=>applyDrawerSide(drawer.dataset.side==='left'?'right':'left'));
    chrome.storage.onChanged?.addListener((changes,area)=>{
      if(area!=='local'||!drawer)return;
      if(changes.theme)applyDrawerTheme(changes.theme.newValue);
      if(changes.drawerSide)applyDrawerSide(changes.drawerSide.newValue,false);
    });

    drawer.querySelector("#wga-close").addEventListener("click",()=>drawer.style.display="none");
    drawer.querySelector("#wga-answer-only").addEventListener("click",()=>{const on=!drawer.classList.contains("answer-only");drawer.classList.toggle("answer-only",on);drawer.querySelector("#wga-answer-only").setAttribute("aria-pressed",String(on));chrome.storage.local.set({answerOnly:on}).catch(()=>{});});
    drawer.querySelectorAll("[data-wga-action]").forEach(btn=>btn.addEventListener("click",()=>{setAction(btn.dataset.wgaAction);if(currentText)analyze(currentText,currentAction)}));
    drawer.querySelector("#wga-send").addEventListener("click",()=>{const q=drawer.querySelector("#wga-question").value.trim();const text=q||currentText;if(!text){drawer.querySelector("#wga-status").textContent="Select text or type a question first.";return}if(q)currentText=q;analyze(text,q?"ask":currentAction)});
    drawer.querySelector("#wga-question").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();drawer.querySelector("#wga-send").click()}});
    drawer.querySelector("#wga-copy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(drawer.querySelector("#wga-answer").innerText);drawer.querySelector("#wga-status").textContent="Answer copied."}catch{drawer.querySelector("#wga-status").textContent="Copy unavailable on this page."}});
  }
  function basicRender(text){
    let escaped=String(text||"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
    escaped=escaped.replace(/(https?:\/\/[^\s<]+)/g, url=>{const clean=url.replace(/[),.]+$/g,"");return `<a href="${clean}" target="_blank" rel="noopener noreferrer" style="color:#087c99;text-decoration:underline;overflow-wrap:anywhere">${clean}</a>${url.slice(clean.length)}`;});
    return escaped.replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/\*\*(.*?)\*\*/g,"<b>$1</b>").replace(/\n/g,"<br>");
  }
  async function analyze(text,action){
    if(busy)return;busy=true;const answer=drawer.querySelector("#wga-answer"),status=drawer.querySelector("#wga-status"),send=drawer.querySelector("#wga-send");
    send.disabled=true;answer.innerHTML='<span class="wga-loading">Searching free sources / calculating…</span>';status.textContent="";
    try{
      const target=drawer.querySelector("#wga-language").value;
      const cfg=await chrome.storage.local.get({topic:"school",answerLanguage:"Auto-detect",teachingLevel:"normal",targetLanguage:"English"});
      const result=await chrome.runtime.sendMessage({type:"WGA_FREE_ANSWER",text,action,targetLanguage:target||cfg.targetLanguage,topic:cfg.topic,answerLanguage:cfg.answerLanguage,teachingLevel:cfg.teachingLevel});
      if(!result?.ok)throw new Error(result?.error||"No answer returned.");
      answer.innerHTML=basicRender(result.text||"No answer returned.");
      status.textContent=result.cached?`Instant · ${result.source}`:(result.source?`Source: ${result.source}`:"");
    }catch(err){answer.textContent="Couldn't get an answer. Check your connection and try again.\n\n"+err.message;status.textContent="The selection is still saved in the panel."}
    finally{busy=false;send.disabled=false}
  }
  document.addEventListener("mouseup",event=>setTimeout(()=>{
    // Do not rebuild the selection toolbar when the user is clicking its own buttons or drawer.
    if (event.target?.closest?.('#wga-selection-bubble, #wga-drawer')) return;
    const text=selectedText();
    if(text.length>=2)makeBubble(text.slice(0,12000),event.clientX,event.clientY);
    else removeBubble();
  },35),true);
  document.addEventListener("keyup",event=>{if(["Shift","ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(event.key)){const text=selectedText();if(text.length>=2){const rect=window.getSelection()?.getRangeAt(0)?.getBoundingClientRect();makeBubble(text.slice(0,12000),rect?.left||20,rect?.bottom||20)}}},true);
  document.addEventListener("scroll",removeBubble,{passive:true,capture:true});
})();